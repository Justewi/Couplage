#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

class Node{
public :
	string id;
	vector<Node> voisins;
	Node(string id){
	id = id;
	};

	void addvoisin(Node n);

};




