#include <stdio.h>
#include <string>

#include "GraphBipartie.h"
#include <vector>

using namespace std;


void GraphBipartie::initializeVector(int nombre_paire_de_noeuds){
	for ( int i = 0; i<nombre_paire_de_noeuds; i++){
		partie1.push_back(Node("n1" + to_string((2*i))));
		partie2.push_back(Node("n2" + to_string((2*i+1))));
}

}
void GraphBipartie::createGraph(double probabilite){
	
	for (n1 : partie1) {
		for (n2 : partie2) {
			if (rand()/RAND_MAX < probabilite){
				n1.addvoisin(n2);
			}
		}
	}

}